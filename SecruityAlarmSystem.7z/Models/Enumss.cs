﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Enumss
    {
        public enum Status
        {
            TurnOff = 1,
            TurnOn = 2,
            Test = 3,
            Unknown = 4
        }
    }
}
