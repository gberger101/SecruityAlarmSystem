﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccessQueries;

namespace UnitTest
{
    [TestClass]
    public class utCustomers : utBase
    {
        [TestMethod]
        public void LoadAllCustomerFromJSON()
        {
            Customer oCustomer = new Customer();
            var customers = oCustomer.ReadJSONFile();
            Assert.AreNotEqual(customers.Count, 0);
        }

        [TestMethod]
        public void getClientIDfromUserID_Valid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromUserID(UserID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.UserID);
            Assert.AreEqual(customer.UserID, UserID_Good);
        }

        [TestMethod]
        public void getClientIDfromUserID_InValid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromUserID(UserID_Bad);
            Assert.IsNotNull(customer);
            Assert.IsNull(customer.UserID);
        }

        [TestMethod]
        public void getClientIDfromConsoleID_Valid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ConsoleID);
            Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);
        }

        [TestMethod]
        public void getClientIDfromConsoleID_InValid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Bad);
            Assert.IsNotNull(customer);
            Assert.IsNull(customer.ConsoleID);
        }

        [TestMethod]
        public void getClientIDfromClientID_Valid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromClientID(ClientID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ClientID);

            Assert.AreEqual(customer.ClientID, ClientID_Good);
        }

        [TestMethod]
        public void getClientIDfromClientID_InValid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromClientID(ClientID_Bad);
            Assert.IsNotNull(customer);
            Assert.IsNull(customer.ClientID);
        }

    }
}
