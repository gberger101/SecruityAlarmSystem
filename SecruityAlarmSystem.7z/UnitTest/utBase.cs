﻿namespace UnitTest
{
    public class utBase
    {
        public string ConsoleID_Good = "Three";
        public string ConsoleID_Bad = "zzzzzzzzz";

        public string ClientID_Good = "222";
        public string ClientID_Bad = "zzzzzzz";

        public string UserID_Good = "2";
        public string UserID_Bad = "9999999";

        public string Color_Good = "Red";
        public string Color_Bad = "badcolor";

    }
}
