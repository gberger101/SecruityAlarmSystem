﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccessQueries;

namespace UnitTest
{
    [TestClass]
    public class utValidateColors : utBase
    {
        /// <summary>
        /// Valid test 
        /// </summary>
        [TestMethod]
        public void IsValidFromHomeReciever_Valid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ConsoleID);
            Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            Assert.IsNotNull(chip);
            Assert.IsNotNull(chip.ConsoleID);
            Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            Assert.AreNotEqual(colors.Count, 0);

            // "ConsoleID":"Three", "ChipColorLeft":"Yellow", "ChipColorRight":"Green", "CurrentStatus":"TurnOff", "LastStatus":"TurnOn", 

            string[] ColorsFromConsoleGood = { "Blue,Yellow", "Yellow,Red", "Red,Green" };

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            Assert.IsTrue(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"));
        }

        /// <summary>
        /// Valid test 
        /// A NEW home console is sending the yyyymmddHHMMSSmiliseconds and although it needs to be validated,
        ///     it cant affect ANY prior code.
        /// </summary>
        [TestMethod]
        public void IsValidFromHomeReciever_Valid_with_yyyymmddHHMMSSmiliseconds()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ConsoleID);
            Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            Assert.IsNotNull(chip);
            Assert.IsNotNull(chip.ConsoleID);
            Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            Assert.AreNotEqual(colors.Count, 0);

            // "ConsoleID":"Three", "ChipColorLeft":"Yellow", "ChipColorRight":"Green", "CurrentStatus":"TurnOff", "LastStatus":"TurnOn", 

            string[] ColorsFromConsoleGood = { "Blue,Yellow", "Yellow,Red", "Red,Green" };

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            Assert.IsTrue(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff", "201712312311591234"));
        }

        /// <summary>
        /// Invalid test test for LEFT circle and left color of FIRST chip
        /// </summary>
        [TestMethod]
        public void IsValidFromHomeReciever_Invalid_LeftCircleAndLeftColorOfFirstChip()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ConsoleID);
            Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            Assert.IsNotNull(chip);
            Assert.IsNotNull(chip.ConsoleID);
            Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            Assert.AreNotEqual(colors.Count, 0);

            string[] ColorsFromConsoleGood = { "Aqua,Blue", "Blue,Red", "Red,Green" }; // Aqua is invalid

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            Assert.IsFalse(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"));
        }

        /// <summary>
        /// Invalid test test for LEFT circle and left color of LAST chip
        /// </summary>
        [TestMethod]
        public void IsValidFromHomeReciever_Invalid_RightCircleAndRightColorOfLastChip()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ConsoleID);
            Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            Assert.IsNotNull(chip);
            Assert.IsNotNull(chip.ConsoleID);
            Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            Assert.AreNotEqual(colors.Count, 0);

            string[] ColorsFromConsoleGood = { "Yellow,Blue", "Blue,Red", "Red,Aqua" }; // Aqua is invalid

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            Assert.IsFalse(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"));
        }

        /// <summary>
        /// Invalid test test because BAD color sent from HOME CONSOLE to Corporate System Watch (Real Time Monitor)
        /// Perhaps there was a NEW color added on a chip that wasn't added to the colors table.
        /// Perhaps a hacker theif is trying to break into the security system.
        /// </summary>
        [TestMethod]
        public void IsValidFromHomeReciever_Invalid_BadColorSent()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            Assert.IsNotNull(customer);
            Assert.IsNotNull(customer.ConsoleID);
            Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            Assert.IsNotNull(chip);
            Assert.IsNotNull(chip.ConsoleID);
            Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            Assert.AreNotEqual(colors.Count, 0);

            string[] ColorsFromConsoleGood = { "Aqua,Blue", "Amber,Red", "Red,Green" }; // Amber is invalid bec not in database

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            Assert.IsFalse(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"));
        }






    }
}
