﻿using DataAccessQueries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecuritConsoleAtHomesConsoleApp
{
    class Program
    {
        private static string ConsoleID_Good = "Three"; // Copied from unit test base class
        private static string ClientID_Good = "222"; // Copied from unit test base class


        static void Main(string[] args)
        {
            Console.WriteLine("2 Tests: A valid test AND an Invalid test sent from Home Console to Security System Watcher");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Valid Home Console ping to Corp System Watcher");
            bool sValidatnStrng = Valid();
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("INVALID Valid Home Console ping to Corp System Watcher");
            string sValidatnStrng2 = InValid();
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("See Unit Tests.  Lots of valid and invalid testing.");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Press <Enter> to close window");
            Console.ReadLine();

        }

        private static bool Valid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            //Assert.IsNotNull(customer);
            //Assert.IsNotNull(customer.ConsoleID);
            //Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            //Assert.IsNotNull(chip);
            //Assert.IsNotNull(chip.ConsoleID);
            //Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            //Assert.AreNotEqual(colors.Count, 0);

            string[] ColorsFromConsoleGood = { "Blue,Yellow", "Yellow,Red", "Red,Green" };

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            //Assert.IsTrue(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"));
            if (oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"))
            {
                return true;
            }
            //return "Actual error";
            return false;
        }

        private static string InValid()
        {
            Customer oCustomer = new Customer();
            var customer = oCustomer.getClientIDfromConsoleID(ConsoleID_Good);
            //Assert.IsNotNull(customer);
            //Assert.IsNotNull(customer.ConsoleID);
            //Assert.AreEqual(customer.ConsoleID, ConsoleID_Good);

            DataAccessQueries.ChipQueries oChip = new DataAccessQueries.ChipQueries();
            Models.Chip chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            //Assert.IsNotNull(chip);
            //Assert.IsNotNull(chip.ConsoleID);
            //Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);

            ColorsQueries oCQ = new ColorsQueries();
            System.Collections.Generic.List<Models.Colors> colors = oCQ.GetAllColors();
            //Assert.AreNotEqual(colors.Count, 0);

            string[] ColorsFromConsoleGood = { "Blue,Yellow", "Purple,Red", "Red,Green" };

            Calculations.ValidateColors oVC = new Calculations.ValidateColors();
            //Assert.IsTrue(oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"));
            if (!oVC.ValidateFromConsole(chip, colors, ColorsFromConsoleGood, "TurnOff"))
            {
                Console.WriteLine("");
                Console.WriteLine("Cannot unlock master panel");
                return "Cannot unlock master panel";
            }
            return "Actual developer error occurred";
        }

    }
}
