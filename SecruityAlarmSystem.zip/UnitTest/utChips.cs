﻿using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace UnitTest
{
    [TestClass]
    public class utChips : utBase
    {
        [TestMethod]
        public void LoadAllChipsFromJSON()
        {
            DataAccessQueries.ChipQueries oChip = new  DataAccessQueries.ChipQueries();
            var chips = oChip.ReadJSONFile();
            Assert.AreNotEqual(chips.Count, 0);
        }

        [TestMethod]
        public void GetChipByConsoleID_Valid()
        {
            DataAccessQueries.ChipQueries oChip = new  DataAccessQueries.ChipQueries();
            var chip = oChip.GetChipByConsoleID(ConsoleID_Good);
            Assert.IsNotNull(chip);
            Assert.IsNotNull(chip.ConsoleID);
            Assert.AreEqual(ConsoleID_Good, chip.ConsoleID);
        }

        [TestMethod]
        public void GetChipByConsoleID_InValid()
        {
            DataAccessQueries.ChipQueries oChip = new  DataAccessQueries.ChipQueries();
            var chips = oChip.ReadJSONFile();
            var chip = oChip.GetChipByConsoleID(ConsoleID_Bad);
            Assert.IsNotNull(chip);
            Assert.IsNull(chip.ConsoleID);
        }

    }
}
