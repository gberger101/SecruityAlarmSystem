﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccessQueries;

namespace UnitTest
{
    [TestClass]
    public class utColors : utBase
    {

        [TestMethod]
        public void LoadAllColorsFromJSON()
        {
            ColorsQueries oCQ = new ColorsQueries();
            var colors = oCQ.ReadJSONFile();
            Assert.AreNotEqual(colors.Count, 0);
        }

        /// <summary>
        /// Never directly call DataAccessCore from anywhere but DataAccessQueries so 
        ///     so GetAllColors() was created
        /// </summary>
        [TestMethod]
        public void GetAllColors()
        {
            ColorsQueries oCQ = new ColorsQueries();
            var colors = oCQ.GetAllColors();
            Assert.AreNotEqual(colors.Count, 0);
        }

        [TestMethod]
        public void ValidateColor_Valid()
        {
            ColorsQueries oCQ = new ColorsQueries();
            var color = oCQ.ValidateColor(Color_Good);
            Assert.IsNotNull(color);
            Assert.IsNotNull(color.Color);
            Assert.AreEqual(color.Color, Color_Good);
        }

        [TestMethod]
        public void ValidateColor_Invalid()
        {
            ColorsQueries oCQ = new ColorsQueries();
            var color = oCQ.ValidateColor(Color_Bad);
            Assert.IsNotNull(color);
            Assert.IsNull(color.Color);
        }


    }
}
